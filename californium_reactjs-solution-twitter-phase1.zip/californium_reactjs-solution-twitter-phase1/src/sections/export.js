import LeftSec from "./left-sec/left-sec";
import RightSec from "./right-sec/right-sec";
import Posts from "./post-sec/posts";

export{
    LeftSec,
    RightSec,
    Posts
}