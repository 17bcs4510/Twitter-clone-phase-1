import SignUpComponent from "../components/signup/signup"

export default function SignUpPage ( ) {
    return(
        <SignUpComponent/>
    )
}