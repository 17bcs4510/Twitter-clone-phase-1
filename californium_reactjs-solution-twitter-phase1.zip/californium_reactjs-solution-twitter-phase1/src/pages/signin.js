import SignInComponent from "../components/signin/signin"

export default function SignInPage () {

    return(
        <SignInComponent/>
    )
}